from flask import Flask, request, jsonify, render_template
import openai

app = Flask(__name__)

# Initialize the OpenAI API key
openai.api_key = "your-openai-api-key"

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict_faculty', methods=['POST'])
def predict_faculty():
    data = request.json
    student_name = data['name']
    subjects = data['subjects']
    hobbies = data['hobbies']
    aspirations = data['aspirations']
    
    # Step 1: Ask OpenAI to predict the faculty
    prediction_response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": f"{student_name} enjoyed these subjects: {subjects}. They love doing {hobbies} in their free time and aspire to become {aspirations}. Based on this information, which university faculty would you recommend for them?"}
        ]
    )
    predicted_faculty = prediction_response['choices'][0]['message']['content']
    
    # Step 2: Ask OpenAI for advice
    advice_response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": f"What advice would you give to a student who is considering joining the {predicted_faculty} faculty? Also, what general advice do you have for any student entering university?"}
        ]
    )
    advice = advice_response['choices'][0]['message']['content']
    
    # Return the predicted faculty and advice
    return jsonify({"predicted_faculty": predicted_faculty, "advice": advice})

if __name__ == '__main__':
    app.run(debug=True)
