from flask import Flask, request, jsonify, render_template
import openai

app = Flask(__name__)

# Initialize the OpenAI API key
openai.api_key = "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"

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict_faculty', methods=['POST'])
def predict_faculty():
    data = request.json
    student_name = data['name']
    subjects = data['subjects']
    hobbies = data['hobbies']
    aspirations = data['aspirations']
    
    # Step 1: Ask OpenAI to predict the faculty
    prediction_response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": f"{student_name} enjoyed these subjects: {subjects}. They love doing {hobbies} in their free time and aspire to become {aspirations}. Based on this information, which university possible faculties would you recommend for them? give the user at least possibble faculties he could attend"}
        ]
    )
    predicted_faculty = prediction_response['choices'][0]['message']['content']
    
    # Step 2: Ask OpenAI for advice
    advice_response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": f"What advice would you give to a student who is considering joining the {predicted_faculty} faculty? Also, what general advice do you have for any student entering university?"}
        ]
    )
    advice = advice_response['choices'][0]['message']['content']
    
    # Return the predicted faculty and advice
    return jsonify({"predicted_faculty": predicted_faculty, "advice": advice})

if __name__ == '__main__':
    app.run(debug=True)
